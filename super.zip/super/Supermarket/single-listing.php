<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Dorne - katalog &amp;Ro'yxat shabloni | Yagona ro'yxat</title>

    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Core Stylesheet -->
    <link href="style.css" rel="stylesheet">

    <!-- Responsive CSS -->
    <link href="css/responsive/responsive.css" rel="stylesheet">

</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="dorne-load"></div>
    </div>

    <div class="dorne-search-form d-flex align-items-center">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="search-close-btn" id="closeBtn">
                        <i class="pe-7s-close-circle" aria-hidden="true"></i>
                    </div>
                    <form action="#" method="get">
                        <input type="search" name="caviarSearch" id="search" placeholder="Search Your Desire Destinations or Events">
                        <input type="submit" class="d-none" value="submit">
                    </form>
                </div>
            </div>
        </div>
    </div>

    <header class="header_area" id="header">
        <div class="container-fluid h-100">
            <div class="row h-100">
                <div class="col-12 h-100">
                    <nav class="h-100 navbar navbar-expand-lg">
                        <a class="navbar-brand" href="index.php"><img src="img/core-img/logo.png" alt=""></a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#dorneNav" aria-controls="dorneNav" aria-expanded="false" aria-label="Toggle navigation"><span class="fa fa-bars"></span></button>
                        <!-- Nav -->
                        <div class="collapse navbar-collapse" id="dorneNav">
                            <ul class="navbar-nav mr-auto" id="dorneMenu">
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php">Bosh sahifa <span class="sr-only">(joriy)</span></a>
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Tadqiq qiling <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="index.php">Bosh sahifa</a>
                                        <a class="dropdown-item" href="explore.php">Tadqiq qiling</a>
                                        <a class="dropdown-item" href="listing.php">Roʻyxat</a>
                                        <a class="dropdown-item" href="single-listing.php">Yagona ro'yxat</a>
                                        <a class="dropdown-item" href="contact.php">A'loqa</a>
                                    </div>
                                </li>
                                <li class="nav-item active dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown2" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Ro'yxatlar <i class="fa fa-angle-down" aria-hidden="true"></i></a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown2">
                                        <a class="dropdown-item" href="index.php">Boah sahifa</a>
                                        <a class="dropdown-item" href="explore.php">Tadqiq qiling</a>
                                        <a class="dropdown-item" href="listing.php">Roʻyxat</a>
                                        <a class="dropdown-item" href="single-listing.php">Yagona ro'yxat</a>
                                        <a class="dropdown-item" href="contact.php">Aloqa</a>
                                    </div>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="contact.php">Aloqa</a>
                                </li>
                            </ul>
                            <!-- Search btn -->
                            <div class="dorne-search-btn">
                                <a id="search-btn" href="#"><i class="fa fa-search" aria-hidden="true"></i> Qidirish</a>
                            </div>
                            <!-- Signin btn -->
                            <div class="dorne-signin-btn">
                                <a href="#">Ro'yxatlarni qo'shish</a>
                            </div>
                            <!-- Add listings btn -->
                            <div class="dorne-add-listings-btn">
                                <a href="#" class="btn dorne-btn">+ Ro'yxatlarni qo'shish</a>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
  
    <div class="breadcumb-area height-700 bg-img bg-overlay" style="background-image: url(img/bg-img/breadcumb.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcumb-content">
                        <div class="map-ratings-review-area d-flex">
                            <a href="#" class="d-flex align-items-center justify-content-center"><img src="img/core-img/map.png" alt=""></a>
                            <a href="#">8.7</a>
                            <a href="#">Sharh yozing</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  
    <section class="dorne-single-listing-area section-padding-100">
        <div class="container">
            <div class="row justify-content-center">
                <!-- Single Listing Content -->
                <div class="col-12 col-lg-8">
                    <div class="single-listing-content">

                        <div class="listing-title">
                            <h4>Burger House Soho</h4>
                            <h6>Birinchi avenyu 83</h6>
                        </div>

                        <div class="single-listing-nav">
                            <nav>
                                <ul id="listingNav">
                                    <li class="active"><a href="#overview">Umumiy koʻrinish</a></li>
                                    <li><a href="#menu">Menyu</a></li>
                                    <li><a href="#review">Sharhlar</a></li>
                                    <li><a href="#lomap">Xaritadagi joylashuv</a></li>
                                </ul>
                            </nav>
                        </div>

                        <div class="overview-content mt-50" id="overview">
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam ac nibh sed mi ullamcorper rhoncus. Curabitur pulvinar vel augue sit amet vestibulum. Proin tempus lacus porta lorem blandit aliquam eget quis ipsum. Vivamus accumsan consequat ligula non volutpat. Sed mollis orci non cursus vestibulum. Pellentesque vitae est a augue laoreet venenatis sed eu felis. Sed cursus magna nec turpis ullamcorper, eget rutrum felis egestas. Nunc odio ex, fermentum efficitur nunc vitae, efficitur hendrerit diam. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam ac nibh sed mi ullamcorper rhoncus. Curabitur pulvinar vel augue sit amet vestibulum. Proin tempus lacus porta lorem blandit aliquam eget quis ipsum.</p>
                            <div class="row mt-5">
                                <div class="col-6">
                                    <label class="custom-control custom-checkbox mb-3">
                                        <input type="checkbox" class="custom-control-input">
                                        <span class="custom-control-indicator"></span>
                                        <span class="custom-control-description">Kredit kartalarini qabul qiladi</span>
                                    </label>
                                </div>
                                <div class="col-6">
                                    <label class="custom-control custom-checkbox mb-3">
                                        <input type="checkbox" class="custom-control-input">
                                        <span class="custom-control-indicator"></span>
                                        <span class="custom-control-description">Velosiped to'xtash joyi</span>
                                    </label>
                                </div>
                                <div class="col-6">
                                    <label class="custom-control custom-checkbox mb-3">
                                        <input type="checkbox" class="custom-control-input">
                                        <span class="custom-control-indicator"></span>
                                        <span class="custom-control-description">Simsiz Internet</span>
                                    </label>
                                </div>
                                <div class="col-6">
                                    <label class="custom-control custom-checkbox mb-3">
                                        <input type="checkbox" class="custom-control-input">
                                        <span class="custom-control-indicator"></span>
                                        <span class="custom-control-description">Rezervasyonlar</span>
                                    </label>
                                </div>
                                <div class="col-6">
                                    <label class="custom-control custom-checkbox mb-3">
                                        <input type="checkbox" class="custom-control-input">
                                        <span class="custom-control-indicator"></span>
                                        <span class="custom-control-description">Shaxsiy avtoturargoh</span>
                                    </label>
                                </div>
                                <div class="col-6">
                                    <label class="custom-control custom-checkbox mb-3">
                                        <input type="checkbox" class="custom-control-input">
                                        <span class="custom-control-indicator"></span>
                                        <span class="custom-control-description">Chekish maydoni</span>
                                    </label>
                                </div>
                                <div class="col-6">
                                    <label class="custom-control custom-checkbox mb-3">
                                        <input type="checkbox" class="custom-control-input">
                                        <span class="custom-control-indicator"></span>
                                        <span class="custom-control-description">Nogironlar aravachasiga kirish mumkin</span>
                                    </label>
                                </div>
                                <div class="col-6">
                                    <label class="custom-control custom-checkbox mb-3">
                                        <input type="checkbox" class="custom-control-input">
                                        <span class="custom-control-indicator"></span>
                                        <span class="custom-control-description">Kuponlar</span>
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="listing-menu-area mt-100" id="menu">
                            <h4>Menyu</h4>
                            <!-- Single Listing Menu -->
                            <div class="single-listing-menu d-flex justify-content-between">
                                <!-- Listing Menu Title -->
                                <div class="listing-menu-title">
                                    <h6>Klassik burger</h6>
                                    <p>Mol go'shti, salat, xantal, mayonez, achchiq, pishloq/p>
                                </div>
                                <!-- Listing Menu Price -->
                                <div class="listing-menu-price">
                                    <h6>$9,90</h6>
                                </div>
                            </div>
                            <!-- Single Listing Menu -->
                            <div class="single-listing-menu d-flex justify-content-between">
                                <!-- Listing Menu Title -->
                                <div class="listing-menu-title">
                                    <h6>Maxsus uy burger</h6>
                                    <p>Mol go'shti, salat, xantal, mayonez, achchiq, pishloq</p>
                                </div>
                                <!-- Listing Menu Price -->
                                <div class="listing-menu-price">
                                    <h6>$9,90</h6>
                                </div>
                            </div>
                            <!-- Single Listing Menu -->
                            <div class="single-listing-menu d-flex justify-content-between">
                                <!-- Listing Menu Title -->
                                <div class="listing-menu-title">
                                    <h6>Klassik burger</h6>
                                    <p>Mol go'shti, salat, xantal, mayonez, achchiq, pishloq</p>
                                </div>
                                <!-- Listing Menu Price -->
                                <div class="listing-menu-price">
                                    <h6>$9,90</h6>
                                </div>
                            </div>
                            <!-- Single Listing Menu -->
                            <div class="single-listing-menu d-flex justify-content-between">
                                <!-- Listing Menu Title -->
                                <div class="listing-menu-title">
                                    <h6>Maxsus uy burger</h6>
                                    <p>Mol go'shti, salat, xantal, pastırma, mayonez, achchiq lazzat, pishloq</p>
                                </div>
                                <!-- Listing Menu Price -->
                                <div class="listing-menu-price">
                                    <h6>$9,90</h6>
                                </div>
                            </div>
                            <a href="#" class="btn dorne-btn mt-50">+ Menyuga qarang</a>
                        </div>

                        <div class="listing-reviews-area mt-100" id="review">
                            <h4>reviews</h4>
                            <div class="single-review-area">
                                <div class="reviewer-meta d-flex align-items-center">
                                    <img src="img/clients-img/1.jpg" alt="">
                                    <div class="reviewer-content">
                                        <div class="review-title-ratings d-flex justify-content-between">
                                            <h5>“Shahardagi eng yaxshi mahsulotlar”</h5>
                                            <div class="ratings">
                                                <img src="img/clients-img/star-fill.png" alt="">
                                                <img src="img/clients-img/star-fill.png" alt="">
                                                <img src="img/clients-img/star-fill.png" alt="">
                                                <img src="img/clients-img/star-fill.png" alt="">
                                                <img src="img/clients-img/star-fill.png" alt="">
                                            </div>
                                        </div>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam ac nibh sed mi ullamcorper rhoncus. Curabitur pulvinar vel augue sit amet vestibulum. Proin tempus lacus porta lorem blandit aliquam eget quis ipsum. Vivamus accumsan consequat ligula non volutpat.</p>
                                    </div>
                                </div>
                                <div class="reviewer-name">
                                    <h6>Xusanov Mansur</h6>
                                    <p>20 dekabr 2023</p>
                                </div>
                            </div>
                            <div class="single-review-area">
                                <div class="reviewer-meta d-flex align-items-center">
                                    <img src="img/clients-img/1.jpg" alt="">
                                    <div class="reviewer-content">
                                        <div class="review-title-ratings d-flex justify-content-between">
                                            <h5>“Sifatli mahsulotlar”</h5>
                                            <div class="ratings">
                                                <img src="img/clients-img/star-fill.png" alt="">
                                                <img src="img/clients-img/star-fill.png" alt="">
                                                <img src="img/clients-img/star-fill.png" alt="">
                                                <img src="img/clients-img/star-fill.png" alt="">
                                                <img src="img/clients-img/star-unfill.png" alt="">
                                            </div>
                                        </div>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam ac nibh sed mi ullamcorper rhoncus. Curabitur pulvinar vel augue sit amet vestibulum. Proin tempus lacus porta lorem blandit aliquam eget quis ipsum. Vivamus accumsan consequat ligula non volutpat.</p>
                                    </div>
                                </div>
                                <div class="reviewer-name">
                                    <h6>Xusanov Saidahmad</h6>
                                    <p>20 Dekabr 2023</p>
                                </div>
                            </div>
                        </div>

                        <div class="location-on-map mt-50" id="lomap">
                            <h4>Xaritadagi joylashuv</h4>
                            <div class="location-map">
                                <div id="locationMap"></div>
                            </div>
                        </div>

                    </div>
                </div>

                <!-- Listing Sidebar -->
                <div class="col-12 col-md-8 col-lg-4">
                    <div class="listing-sidebar">

                        <!-- Listing Verify -->
                        <div class="listing-verify">
                            <a href="#" class="btn dorne-btn w-100"><i class="fa fa-check pr-3"></i>Tasdiqlangan roʻyxat</a>
                        </div>

                        <!-- Book A Table Widget -->
                        <div class="book-a-table-widget mt-50">
                            <h6>Jadvalni bron qilish</h6>
                            <form action="#" method="get">
                                <select class="custom-select" id="destinations">
                                <option selected>Kim keladi</option>
                                <option value="1">Toshkent</option>
                                <option value="2">Samarqand</option>
                                <option value="3">Surxondaryo</option>
                                <option value="4">Jizzax</option>
                                <option value="5">Sirdaryo</option>
                            </select>
                                <select class="custom-select" id="catagories">
                                <option selected> Mehmon 1</option>
                                <option value="1">Mehmon 2</option>
                                <option value="3">Mehmon 3</option>
                                <option value="3">Mehmon 4</option>                 
                            </select>
                                <button type="submit" class="btn dorne-btn bg-white text-dark"><i class="fa fa-search pr-2" aria-hidden="true"></i> Qidirilmoqda</button>
                            </form>
                        </div>

                        <!-- Opening Hours Widget -->
                        <div class="opening-hours-widget mt-50">
                            <h6>Ish vaqti</h6>
                            <ul class="opening-hours">
                                <li>
                                    <p>Dushanba</p>
                                    <p>yopiq</p>
                                </li>
                                <li>
                                    <p>Seshanba</p>
                                    <p>9:00 - 13:00</p>
                                </li>
                                <li>
                                    <p>Chorshanba</p>
                                    <p>9:00 - 13:00</p>
                                </li>
                                <li>
                                    <p>Payshanba</p>
                                    <p>9:00 - 13:00</p>
                                </li>
                                <li>
                                    <p>Juma</p>
                                    <p>9:00 - 13:00</p>
                                </li>
                                <li>
                                    <p>Shanba</p>
                                    <p>9:00 - 13:00</p>
                                </li>
                                <li>
                                    <p>Yakshanba</p>
                                    <p>9:00 - 13:00</p>
                                </li>
                            </ul>
                        </div>

                        <!-- Author Widget -->
                        <div class="author-widget mt-50 d-flex align-items-center">
                            <img src="img/clients-img/1.jpg" alt="">
                            <div class="authors-name">
                                <a href="#">Xusanov Oybek</a>
                                <p>Muallif</p>
                            </div>
                        </div>

                        <!-- Contact Form -->
                        <div class="contact-form contact-form-widget mt-50">
                            <h6>Biz bilan bog'lanish</h6>
                            <form action="#">
                                <div class="row">
                                    <div class="col-12">
                                        <input type="text" name="name" class="form-control" placeholder="Your Name">
                                    </div>
                                    <div class="col-12">
                                        <input type="email" name="email" class="form-control" placeholder="Email Address">
                                    </div>
                                    <div class="col-12">
                                        <textarea name="message" class="form-control" id="Message" cols="30" rows="10" placeholder="Your Message"></textarea>
                                    </div>
                                    <div class="col-12">
                                        <button type="submit" class="btn dorne-btn">Yuborish</button>
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** Single Listing Area End ***** -->

    <!-- ****** Footer Area Start ****** -->
    <footer class="dorne-footer-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 d-md-flex align-items-center justify-content-between">
                    <div class="footer-text">
                        <p>
                        Mualliflik huquqi &copy;<script>document.write(new Date().getFullYear());</script> Barcha huquqlar himoyalangan | Ushbu loyiha Xusanov Oybek va Xusanov Saidahmad tomonidan ishlab chiqilgan</a>
                        </p>
                    </div>
                    <div class="footer-social-btns">
                        <a href="#"><i class="fa fa-linkedin" aria-haspopup="true"></i></a>
                        <a href="#"><i class="fa fa-behance" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-dribbble" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-twitter" aria-haspopup="true"></i></a>
                        <a href="#"><i class="fa fa-facebook" aria-haspopup="true"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap-4 js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/others/plugins.js"></script>
    <!-- Google Maps js -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDk9KNSL1jTv4MY9Pza6w8DJkpI_nHyCnk"></script>
    <script src="js/google-map/location-map-active.js"></script>
    <!-- Active JS -->
    <script src="js/active.js"></script>
</body>

</html>