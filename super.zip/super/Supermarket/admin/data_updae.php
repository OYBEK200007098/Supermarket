<?php include"footer.php"?> 
<?php include"side_bar.php";?>
<?php include"footer_script.php";?>