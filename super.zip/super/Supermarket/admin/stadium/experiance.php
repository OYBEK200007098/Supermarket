
<!DOCTYPE HTML>
<html>
<head>
<title>Stadion</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="js/jquery.min.js"></script>
    <!-- light-box -->
	<script type="text/javascript" src="js/jquery.fancybox.js"></script>
	<link rel="stylesheet" type="text/css" href="css/jquery.fancybox.css" media="screen" />
   <script type="text/javascript">
		$(document).ready(function() {
		
			$('.fancybox').fancybox();

		});
	</script>
</head>
<body>
	<?php include"navigation.php";?>
     <div class="main">
      <div class="shop_top">
		<div class="container">
			<div class="row ex_box">
				<h3 class="m_2">O`YINLARIMIZ</h3>
				<div class="col-md-4 team1">
				<div class="img_section magnifier2">
				  <a class="fancybox" href="images/kho.jpg" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img style="height:300px; width:400px"   src="images/kho.jpg" class="img-responsive" alt=""><span> </span>
					<div class="img_section_txt">
						KHO KHO
					</div>
				</a></div>
				</div>
				<div class="col-md-4 team1">
				<div class="img_section magnifier2">
				  <a class="fancybox" href="images/tenis.jpg" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img style="height:300px; width:400px"  src="images/tenis.jpg" class="img-responsive" alt=""><span> </span>
					<div class="img_section_txt">
					TENNIS VA VOLEYBOL
					</div>
				</a></div>
				</div>
				<div class="col-md-4 team1">
				<div class="img_section magnifier2">
				  <a class="fancybox" href="images/kabaddi.jpg" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img style="height:300px; width:400px"  src="images/kabaddi.jpg" class="img-responsive" alt=""><span> </span>
					<div class="img_section_txt">
						KABADDI
					</div>
				</a></div>
				</div>
		    </div>
		    <div class="row ex_box">
				<div class="col-md-4 team1">
				<div class="img_section magnifier2">
				  <a class="fancybox" href="images/foot.jpg" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img style="height:300px; width:400px" src="images/foot.jpg" class="img-responsive" alt=""><span> </span>
					<div class="img_section_txt">
						FOOTBAL
					</div>
				</a></div>
				</div>
				<div class="col-md-4 team1">
				<div class="img_section magnifier2">
				  <a class="fancybox" href="images/virat.jpg" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="images/virat.jpg" style="height:300px; width:400px"  class="img-responsive" alt=""><span> </span>
					<div class="img_section_txt">
					Og`riqning ketishiga yo`l qo`ymang
					</div>
				</a></div>
				</div>
				<div class="col-md-4 team1">
				<div class="img_section magnifier2">
				  <a class="fancybox" href="images/hockey.jpg" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="images/hockey.jpg" style="height:300px; width:400px" class="img-responsive" alt=""><span> </span>
					<div class="img_section_txt">
					Og`riqning ketishiga yo`l qo`ymang
					</div>
				</a></div>
				</div>
		    </div>
		    <div class="row ex1_box">
			   <div class="col-md-4 team1">
				<div class="img_section magnifier2">
				  <a class="fancybox" href="images/bat.jpg" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="images/bat.jpg" style="height:300px; width:400px" class="img-responsive" alt=""><span> </span>
					<div class="img_section_txt">
					Og`riqning ketishiga yo`l qo`ymang
					</div>
				</a></div>
				</div>
				<div class="col-md-4 team1">
				<div class="img_section magnifier2">
				  <a class="fancybox" href="images/polo.jpg" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="images/polo.jpg" style="height:300px; width:400px"class="img-responsive" alt=""><span> </span>
					<div class="img_section_txt">
					Og`riqning ketishiga yo`l qo`ymang
					</div>
				</a></div>
				</div>
				<div class="col-md-4 team1">
				<div class="img_section magnifier2">
				  <a class="fancybox" href="images/basket.jpeg" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="images/basket.jpeg" style="height:300px; width:400px"class="img-responsive" alt=""><span> </span>
					<div class="img_section_txt">
					Og`riqning ketishiga yo`l qo`ymang
					</div>
				</a></div>
			   </div>
		    </div>
		 </div>
	   </div>
	  </div>
	  <div class="footer">
			<div class="container">
				<div class="row">
					<div class="col-md-3">
						<ul class="footer_box">
							<h4>Mahsulotlar</h4>
							<li><a href="#">Aql</a></li>
							<li><a href="#">Ayollar</a></li>
							<li><a href="#">Yoshlar</a></li>
						</ul>
					</div>
					<div class="col-md-3">
						<ul class="footer_box">
							<h4>Haqida</h4>
							<li><a href="#">Karyera va amaliyot</a></li>
							<li><a href="#">Homiylik</a></li>
							<li><a href="#">Jamoa</a></li>
							<li><a href="#">Katalog so`rovi/yuklab olish</a></li>
						</ul>
					</div>
					<div class="col-md-3">
						<ul class="footer_box">
							<h4>Mijozlarni qo`llab-quvvatlash</h4>
							<li><a href="#">Biz bilan bog`lanish</a></li>
							<li><a href="#">Yuk tashish va buyurtmani kuzatish</a></li>
							<li><a href="#">Oson Qaytish</a></li>
							<li><a href="#">Kafolat</a></li>
							<li><a href="#">Bog`lovchi qismlarni almashtirish</a></li>
						</ul>
					</div>
					<div class="col-md-3">
						<ul class="footer_box">
							<h4>Axborot byulleteni</h4>
							<div class="footer_search">
				    		   <form>
				    			<input type="text" value="Enter your email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter your email';}">
				    			<input type="submit" value="Go">
				    		   </form>
					        </div>
							<ul class="social">	
							  <li class="facebook"><a href="#"><span> </span></a></li>
							  <li class="twitter"><a href="#"><span> </span></a></li>
							  <li class="instagram"><a href="#"><span> </span></a></li>	
							  <li class="pinterest"><a href="#"><span> </span></a></li>	
							  <li class="youtube"><a href="#"><span> </span></a></li>										  				
						    </ul>
		   				</ul>
					</div>
				</div>
				<div class="row footer_bottom">
				    <div class="copy">
			           <p>© 2014 Shablon muallifi <a href="http://w3layouts.com" target="_blank">chiqish yo`llari</a></p>
		            </div>
					  <dl id="sample" class="dropdown">
				        <dt><a href="#"><span>Hududni o`zgartirish</span></a></dt>
				        <dd>
				            <ul>
				                <li><a href="#">Australia<img class="flag" src="images/as.png" alt="" /><span class="value">AS</span></a></li>
				                <li><a href="#">Shri Lanka<img class="flag" src="images/srl.png" alt="" /><span class="value">SL</span></a></li>
				                <li><a href="#">Yangi Zellandiya<img class="flag" src="images/nz.png" alt="" /><span class="value">NZ</span></a></li>
				                <li><a href="#">Pokistan<img class="flag" src="images/pk.png" alt="" /><span class="value">Pk</span></a></li>
				                <li><a href="#">Byuk Britaniya<img class="flag" src="images/uk.png" alt="" /><span class="value">UK</span></a></li>
				                <li><a href="#">AQSH<img class="flag" src="images/us.png" alt="" /><span class="value">US</span></a></li>
				            </ul>
				         </dd>
	   				  </dl>
   				</div>
			</div>
		</div>
</body>	
</html>