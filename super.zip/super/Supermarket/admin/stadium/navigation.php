<div class="header">
		<div class="container">
			<div class="row">
			  <div class="col-md-12">
				 <div class="header-left">
					 
					 <div class="menu">
						  <a class="toggleMenu" href="#"><img src="images/nav.png" alt="" /></a>
						    <ul class="nav" id="nav">
						    	
						    	<li><a href="index.php">Bohi sahifa</a></li>
						    	<li><a href="signin.php">Tizimga kirish</a></li>
						    	<li><a href="login.php">Kirish</a></li>
						    	<li><a href="change_password.php">Parolni o`zgartirish</a></li>
						        <li><a href="reset_password.php">Parolni tiklash</a></li>
						    	<li><a href="about.php">Haqida</a></li>
						    	<li><a href="logout.php">Chiqish</a></li>
						        <li><a href="contact.php">A`loqa</a></li>								
								<div class="clear"></div>
							</ul>
							<script type="text/javascript" src="js/responsive-nav.js"></script>
				    </div>							
	    		    <div class="clear"></div>
	    	    </div>
	             
	      </div>
		 </div>
	    </div>
	</div>