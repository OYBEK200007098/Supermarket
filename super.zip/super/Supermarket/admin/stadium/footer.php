<div class="footer">
			<div class="container">
				
				<div class="copy">
			           <p>© 2021  <a href="" target="_blank"></a></p>
		            </div>
			</div>
		</div>